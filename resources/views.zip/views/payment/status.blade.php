@extends('layouts.home')
@section('title','Payment Status')
@section('content')
<section>
      <div class="container">
        <nav aria-label="breadcrumb" role="navigation">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
            <li aria-current="page" class="breadcrumb-item active">Payment Status</li>
          </ol>
        </nav>
        <div class="row">
          <div class="col-xl-8 text-content" style="min-height: 300px;">

	
	




	</div>
	</div>
	</div>

</section>
@endsection
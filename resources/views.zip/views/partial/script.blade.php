 <!-- footer-->
    <footer class="footer">
  
      <div class="copyrights">       
        <div class="container text-center">
          <p>&copy; 2018 University</p>
        </div>
      </div>
    </footer>

    <!-- JavaScript files-->
    <script src="vendor_f/jquery/jquery.min.js"></script>
    <script src="vendor_f/popper.js/umd/popper.min.js"> </script>
    <script src="vendor_f/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor_f/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor_f/swiper/js/swiper.js"></script>
    <script src="vendor_f/lity/lity.js"></script>
    <script src="vendor_f/bootstrap-select/js/bootstrap-select.js"></script>
   <script src="js/front.js"></script>